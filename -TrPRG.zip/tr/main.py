import pygame
import sys
import string
import random
import pyperclip
import datetime

settings = open("data/settings/settings.txt","r")
settings_ = settings.readlines()

for el in settings_:
    settings_[settings_.index(el)] = (el.strip("\n"))
for el in settings_:
    if el == "True":
        settings_[settings_.index(el)] = True
    elif el == "False":
        settings_[settings_.index(el)] = False

pygame.init()
screen = pygame.display.set_mode((600, 400))
pygame.display.set_caption("Tr_pass_gen")

font = pygame.font.Font(None, 25)
min_font = pygame.font.Font(None, 20)
clock = pygame.time.Clock()

icon_ = pygame.image.load("data/images/icon_.jpeg")
pygame.display.set_icon(icon_)

dark_mode = True

if dark_mode:
    WHITE = (0, 0, 0)
    WHITE_ = (225, 225, 225)
    BLACK = (225, 225, 225)
    GRAY = (200, 200, 200)
    BLUE = (0, 125, 225)
    DARK_BLUE = (0, 0, 225)
    GREEN = (0, 200, 0)
else:
    WHITE = (255, 255, 255)
    WHITE_ = (125, 125, 125)
    BLACK = (0, 0, 0)
    GRAY = (200, 200, 200)
    BLUE = (0, 120, 215)
    DARK_BLUE = (0, 0, 255)
    GREEN = (0, 200, 0)

user_text = settings_[6]
user_text2 = settings_[8]
user_text3 = settings_[7]

user_text3_max_digits = 2
user_text_max_digits = 20

user_text2_max_digits = 14

password_text = " " * int(settings_[7])

input_box_text_display = '[caratteri ammessi] [se vuoto tutti i caratteri speciali vengono ammessi]'
input_box_text2_display = '[Nome salvataggio]'
range_text_label = "[Lunghezza generazione]"

input_active = False
input_2_active = False
input_3_active = False


checkboxes = [
    {"label": "Seleziona tutto", "checked": settings_[0] , "rect": pygame.Rect(20, 120, 20, 20)},
    {"label": "Lettere minuscole", "checked": settings_[1], "rect": pygame.Rect(50, 150, 20, 20)},
    {"label": "Numeri", "checked": settings_[2], "rect": pygame.Rect(50, 180, 20, 20)},
    {"label": "Lettere maiuscole", "checked": settings_[3], "rect": pygame.Rect(50, 210, 20, 20)},
    {"label": "Simboli", "checked": settings_[4], "rect": pygame.Rect(50, 240, 20, 20)},
    {"label": "Salva la generazione", "checked": settings_[5], "rect": pygame.Rect(200, 330, 20, 20)}
]

for item in checkboxes:
    if item["label"] == "Simboli":
        input_box = pygame.Rect(item["rect"].x +120 , item["rect"].y , 200, 25)
    if item["label"] == "Salva la generazione":
        input_box2 = pygame.Rect(item["rect"].x + 150 , item["rect"].y + 30, 200, 25)

input_box3 = pygame.Rect(250 , 87, 80, 25)

button_rect = pygame.Rect(50, 320, 100, 40)

settings.close()

def genera():
    sel = [cb["label"] for cb in checkboxes if cb["checked"]]
    password = ""
    caratteri = ""
    if (sel != []) and not (len(sel) == 1 and "Salva la generazione" in sel):
        if "Lettere minuscole" in sel:
            caratteri +=  string.ascii_lowercase
        if "Numeri" in sel:
            caratteri += string.digits
        if "Lettere maiuscole" in sel:
            caratteri += string.ascii_uppercase
        if "Simboli" in sel:
            if user_text == "":
                caratteri += string.punctuation
            else:
                caratteri += user_text
    else:
        caratteri += string.ascii_lowercase + string.digits + string.ascii_uppercase + string.punctuation

    password = ''.join(random.choices(caratteri, k=int(user_text3)))

    return password

def draw_checkboxes():
    for item in checkboxes:
        rect = item["rect"]
        if rect.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(screen, BLUE, item["rect"], 2)
        else:
            pygame.draw.rect(screen, BLACK, item["rect"], 2)
        if item["checked"]:
            inner = item["rect"].inflate(-6, -6)
            pygame.draw.rect(screen, BLUE, inner)
            
            if item["label"] == "Simboli":
                if input_active:
                    pygame.draw.rect(screen, DARK_BLUE, input_box, 3)
                else:
                    if input_box.collidepoint(pygame.mouse.get_pos()):
                         pygame.draw.rect(screen, BLUE, input_box, 2)
                    else:
                        pygame.draw.rect(screen, BLACK, input_box, 2)
                        
                text_surface = font.render(user_text, True, BLACK)
                screen.blit(text_surface, (item["rect"].centerx + 215 - len(user_text)*5, item["rect"].y + 4))
                text_surface_input_render = min_font.render(input_box_text_display[:20], True, BLACK)
                screen.blit(text_surface_input_render, (item["rect"].x + 325, item["rect"].y + 5))
                text_surface_input_render = min_font.render(input_box_text_display[20:], True, BLACK)
                screen.blit(text_surface_input_render, (item["rect"].x, item["rect"].y + 40))
            if item["label"] == "Salva la generazione":
                if input_2_active:
                    pygame.draw.rect(screen, DARK_BLUE, input_box2, 3)
                else:
                    if input_box2.collidepoint(pygame.mouse.get_pos()):
                        pygame.draw.rect(screen, BLUE, input_box2, 2)
                    else:
                        pygame.draw.rect(screen, BLACK, input_box2, 2)
                text_surface = font.render(user_text2, True, BLACK)
                screen.blit(text_surface, (item["rect"].right +135, item["rect"].y + 33))
                text_surface_input2_render = min_font.render(input_box_text2_display, True, BLACK)
                screen.blit(text_surface_input2_render, (item["rect"].x, item["rect"].y + 35))
        label_surface = font.render(item["label"], True, BLACK)
        screen.blit(label_surface, (item["rect"].right + 10, item["rect"].y))
            
def draw_button():
    if button_rect.collidepoint(pygame.mouse.get_pos()):
        pygame.draw.rect(screen, BLUE, button_rect,2)
        label_surface = font.render("GENERA", True, BLUE)
    else:
        pygame.draw.rect(screen, BLACK, button_rect,2)
        label_surface = font.render("GENERA", True, BLACK)
    screen.blit(label_surface, (button_rect.x + 12, button_rect.y + 12))

sel = [cb["label"] for cb in checkboxes if cb["checked"]]

while True:
    screen.fill(WHITE)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            settings_a = open("data/settings/settings.txt","w")
            s = ""
            for el in checkboxes:
                s += str(el["checked"]) + "\n"
            settings_a.write(s)
            user_text_ = user_text + "\n"
            settings_a.write(user_text_)
            user_text_3 = user_text3 + "\n"
            settings_a.write(user_text_3)
            user_text_2 = user_text2 + "\n"
            settings_a.write(user_text_2)
            settings_a.close()
            settings_a.close()
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            input_active = input_box.collidepoint(event.pos)
            input_2_active = input_box2.collidepoint(event.pos)
            input_3_active = input_box3.collidepoint(event.pos)
            for item in checkboxes:
                if item["rect"].collidepoint(event.pos):
                    item["checked"] = not item["checked"]
                    sel = [cb["label"] for cb in checkboxes if cb["checked"]]
                    if item["label"] == "Seleziona tutto" and item["checked"]:
                        for items in checkboxes:
                            if items["label"] != "Salva la generazione" and items["label"] != "Seleziona tutto":
                                items["checked"] = True
                    all = True
                    for items in checkboxes:
                        if items["label"] != "Seleziona tutto" and items["label"] != "Salva la generazione":
                            if items["checked"] == False:
                                all = False
                    if not all:
                        for items in checkboxes:
                            if items["label"] == "Seleziona tutto" and items["label"] != "Salva la generazione":
                                items["checked"] = False
                    else:
                        for items in checkboxes:
                            if items["label"] == "Seleziona tutto" and items["label"] != "Salva la generazione":
                                items["checked"] = True
                                
            if button_rect.collidepoint(event.pos):
                password_text = genera()
                if "Salva la generazione" in sel:
                    print(f"salvataggio: {password_text}")
                    data = open("data/saves/data.txt", "a")
                    if user_text2 != "":
                        save = f"({user_text2}) [{datetime.datetime.now()}]: {password_text}\n"
                    else:
                        save = f"(---) [{datetime.datetime.now()}]: {password_text}\n"
                    data.write(save)
                    data.close()
                user_text2 = ""
                
                for item in checkboxes:
                    if item["label"] == "Salva la generazione":
                        item["checked"] = False

        elif event.type == pygame.KEYDOWN and input_active:
            if event.key == pygame.K_BACKSPACE:
                user_text = user_text[:-1]
            else:
                user_text += event.unicode
        elif event.type == pygame.KEYDOWN and input_2_active:
            if event.key == pygame.K_BACKSPACE:
                user_text2 = user_text2[:-1]
            else:
                user_text2 += event.unicode
        elif event.type == pygame.KEYDOWN and input_3_active:
            if event.key == pygame.K_BACKSPACE:
                user_text3 = user_text3[:-1]
            else:
                user_text3 += event.unicode

    text_surface = font.render(f"[Generazione]", True, BLACK)
    screen.blit(text_surface, (20, 20))

    text_surface = font.render(f"{password_text}", True, BLACK)
    pass_rect = text_surface.get_rect()
    pass_rect.topleft = (150, 20)
    pygame.draw.rect(screen, BLACK, (pass_rect.x-5, pass_rect.y-5, pass_rect.width + 10, pass_rect.height + 10), 2)
    if pass_rect.collidepoint(pygame.mouse.get_pos()):
        text_surface = font.render(f"{password_text}", True, BLUE)
        if event.type == pygame.MOUSEBUTTONDOWN:
            pyperclip.copy(password_text)
            text_surface = font.render(f"{password_text}", True, DARK_BLUE)
    else:
        text_surface = font.render(f"{password_text}", True, BLACK)
    screen.blit(text_surface, (150, 20))

    if user_text3 != "":
        if not user_text3.isdigit():
            user_text3 = user_text3[:-1]
        if len(user_text3) > user_text3_max_digits:
            user_text3 = user_text3[:-1]
        if int(user_text3) > 40:
            user_text3 = "40"
            
    if user_text2 != "":
        if len(user_text2) > user_text2_max_digits:
            user_text2 = user_text2[:-1]

    if input_3_active:
        pygame.draw.rect(screen, DARK_BLUE, input_box3, 3)
    else:
        if input_box3.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(screen, BLUE, input_box3, 2)
        else:
            pygame.draw.rect(screen, BLACK, input_box3, 2)

    text_surface = font.render(user_text3, True, BLACK)
    screen.blit(text_surface, (input_box3.centerx-len(user_text3)*5,92))
    text_surface = font.render(range_text_label, True, BLACK)
    screen.blit(text_surface, (20, 90))

    if user_text != "":
        if len(user_text) > user_text_max_digits:
            user_text = user_text[:-1]
        if user_text[len(user_text)-1] == " " or (not user_text[len(user_text)-1] in string.punctuation) or user_text.count(user_text[len(user_text)-1]) == 2:
            user_text = user_text[:-1]

    draw_checkboxes()
    draw_button()

    pygame.display.flip()
    clock.tick(30)