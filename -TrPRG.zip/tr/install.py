import tkinter as tk

import subprocess
import sys
import json

required_packages = ["pyperclip", "pygame","pywin32"]
actual_packages = [pkg['name'] for pkg in json.loads(subprocess.run([sys.executable, "-m", "pip", "list", "--format=json"], capture_output=True, text=True).stdout)]

def collegamento():
    import os
    import sys
    from pathlib import Path
    import win32com.client

    script_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
    target_file = "main.py"
    target_path = os.path.join(script_dir, target_file)

    desktop_path = Path.home() / "Desktop"
    shortcut_path = desktop_path / f"TrPRG.lnk"

    shell = win32com.client.Dispatch("WScript.Shell")
    shortcut = shell.CreateShortcut(str(shortcut_path))

    pythonw_path = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    shortcut.TargetPath = pythonw_path
    shortcut.Arguments = f'"{target_path}"'
    shortcut.WorkingDirectory = script_dir
    shortcut.IconLocation = r"C:\Windows\System32\moricons.dll"

    shortcut.save()

    print(f"Collegamento creato senza console: {shortcut_path}")


if not set(required_packages).issubset(set(actual_packages)):
    def risposta(valore):
        selezione_checkbox = checkbox_var.get()
        root.destroy()
        if valore:

            for package in required_packages:
                if not package in actual_packages:
                    subprocess.run([sys.executable, "-m", "pip", "install", package])
                else:
                    print(f"[{package}] already installed!")

        if selezione_checkbox:
            subprocess.run(["python", "main.py"])

    # Crea la finestra principale
    root = tk.Tk()
    root.title("Installazione")
    root.geometry("300x180")

    # Checkbox
    checkbox_var = tk.BooleanVar()
    tk.Checkbutton(root, text="Avvia il programma dopo l'installazione", variable=checkbox_var).pack(pady=10)

    # Domanda
    tk.Label(root, text="Il programma richiede l'installazione di\nlibrerie python. Continuare l'installazione?").pack(pady=5)

    # Bottoni Sì / No
    frame_bottoni = tk.Frame(root)
    frame_bottoni.pack(pady=10)

    tk.Button(frame_bottoni, text="Sì", width=10, command=lambda: risposta(True)).pack(side="left", padx=5)
    tk.Button(frame_bottoni, text="No", width=10, command=lambda: risposta(False)).pack(side="left", padx=5)

    root.mainloop()

    #---------------------------------------------------------------------------------------------------------
else:
    collegamento()
    subprocess.run(["python", "main.py"])